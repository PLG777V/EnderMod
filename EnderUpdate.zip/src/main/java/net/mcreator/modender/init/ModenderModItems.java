
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modender.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.modender.item.EnderSwordItem;
import net.mcreator.modender.item.EnderShovelItem;
import net.mcreator.modender.item.EnderPickaxeItem;
import net.mcreator.modender.item.EnderIngotItem;
import net.mcreator.modender.item.EnderHoeItem;
import net.mcreator.modender.item.EnderAxeItem;
import net.mcreator.modender.item.EnderArmorItem;
import net.mcreator.modender.ModenderMod;

public class ModenderModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ModenderMod.MODID);
	public static final RegistryObject<Item> ENDER_INGOT = REGISTRY.register("ender_ingot", () -> new EnderIngotItem());
	public static final RegistryObject<Item> ENDER_ORE = block(ModenderModBlocks.ENDER_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ENDER_BLOCK = block(ModenderModBlocks.ENDER_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ENDER_PICKAXE = REGISTRY.register("ender_pickaxe", () -> new EnderPickaxeItem());
	public static final RegistryObject<Item> ENDER_AXE = REGISTRY.register("ender_axe", () -> new EnderAxeItem());
	public static final RegistryObject<Item> ENDER_SWORD = REGISTRY.register("ender_sword", () -> new EnderSwordItem());
	public static final RegistryObject<Item> ENDER_SHOVEL = REGISTRY.register("ender_shovel", () -> new EnderShovelItem());
	public static final RegistryObject<Item> ENDER_HOE = REGISTRY.register("ender_hoe", () -> new EnderHoeItem());
	public static final RegistryObject<Item> ENDER_ARMOR_HELMET = REGISTRY.register("ender_armor_helmet", () -> new EnderArmorItem.Helmet());
	public static final RegistryObject<Item> ENDER_ARMOR_CHESTPLATE = REGISTRY.register("ender_armor_chestplate",
			() -> new EnderArmorItem.Chestplate());
	public static final RegistryObject<Item> ENDER_ARMOR_LEGGINGS = REGISTRY.register("ender_armor_leggings", () -> new EnderArmorItem.Leggings());
	public static final RegistryObject<Item> ENDER_ARMOR_BOOTS = REGISTRY.register("ender_armor_boots", () -> new EnderArmorItem.Boots());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
