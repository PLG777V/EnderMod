
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modender.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.modender.block.EnderOreBlock;
import net.mcreator.modender.block.EnderBlockBlock;
import net.mcreator.modender.ModenderMod;

public class ModenderModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ModenderMod.MODID);
	public static final RegistryObject<Block> ENDER_ORE = REGISTRY.register("ender_ore", () -> new EnderOreBlock());
	public static final RegistryObject<Block> ENDER_BLOCK = REGISTRY.register("ender_block", () -> new EnderBlockBlock());
}
